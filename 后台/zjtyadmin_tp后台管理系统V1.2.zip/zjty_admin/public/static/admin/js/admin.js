//表格内单独一条删除操作
function del_data(thisbtn)
{
    var thisid = $(thisbtn).attr('thisid');
    var delurl = $(thisbtn).attr('delurl');
    var removeTr = $(thisbtn).attr('removeTr');//存在值则移除该行

    if(removeTr)
        var thisobj = thisbtn;
    else
        var thisobj = false;


    wangchen.confirm(thisid, delurl,thisobj);
    return false;
}

/**
 * 表格内修改一条
 * @param thisbtn
 */
function edit_data(thisbtn)
{
    var editurl = $(thisbtn).attr('editurl');

    location.href = editurl;
}


//改变状态
function change_status(thisbtn)
{
    var statusurl = $(thisbtn).attr('statusurl');
    var id = $(thisbtn).attr('thisid');
    $.ajax({
        type : 'post',
        url : statusurl,
        dataType : 'json',
        success : function(data){
            if(data.code == 1)
            {
                $('#statushtml'+id).html('<span class="label label-info">开启</span>');
                $(thisbtn).attr('statusurl',data.data.statusurl);

                alert_msg.success(data.msg);
            }
            else if(data.code == 2)
            {
                $('#statushtml'+id).html('<span class="label label-danger">禁用</span>');
                $(thisbtn).attr('statusurl',data.data.statusurl);

                alert_msg.error(data.msg);
            }
            else
            {
                alert_msg.error(data.msg);
            }
        },
        error : function(XMLHttpRequest, textStatus, errorThrown) {
            alert_msg.error('网络异常，请稍后重试!');
        }
    });
}