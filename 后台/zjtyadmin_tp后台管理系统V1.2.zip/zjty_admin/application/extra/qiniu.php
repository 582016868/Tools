<?php
/**
 * Created by PhpStorm.
 * User: baidu
 * Date: 17/7/31
 * Time: 上午12:37
 */
return [
    'ak' => '8VmI78kVGn9VahZi-KjIokyubxWxteHVkA2pbjd',
    'sk' => 'S64N4SPi2atSVVL9uBoXzG4DJtDCQVoOtou0VIu',
    'bucket' => 'imoocapp',
    'image_url' => 'http://otwueljs0.bkt.clouddn.com',
];