<?php
/**
 * Created by PhpStorm.
 * User: baidu
 * Date: 17/7/31
 * Time: 上午1:51
 */

return [
    'lists' => [
        1 => '综艺',
        2 => '明星',
        3 => '韩娱',
        4 => '看点'
    ],
];