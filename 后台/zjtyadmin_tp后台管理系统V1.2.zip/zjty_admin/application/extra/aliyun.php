<?php
/**
 * 阿里云相关的配置
 * Created by PhpStorm.
 * User: baidu
 * Date: 17/7/31
 * Time: 上午12:37
 */
return [
    'appKey' => '2452979',
    'secretKey' => 'ec6d90dc793b4cc824183f71710e1ee',
    'signName' => 'singwa娱乐app',
    'templateCode' => 'SMS_75915048',
    'identify_time' => 12000000,
    'top_sdk_work_dir' => '/tmp/',
];