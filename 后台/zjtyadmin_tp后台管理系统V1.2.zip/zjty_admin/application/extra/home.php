<?php

return [
   'cate_status' => 1, //分类状态
   'article_status' => 1, //文章状态
   'list_rows' => 6, //文章列数
   'banner_ad_position_id' => 1, //轮播图片广告位id
   'banner_ad_status' => 1, //轮播图片状态
   'banner_ad_size' => 5, //轮播图片状态
    'user_status' => 1, //用户注册默认状态
    'register_code' => 0, //开放注册验证码功能
    'register_email_subject' => '欢迎注册煮酒听雨博客，请验证登录邮箱',
    'register_email_content' => '欢迎注册煮酒听雨博客！请输入下面验证码来认证您的邮箱<br/>验证码：',
    'register_user_groupid' => 1, //注册会员默认组


];